package com.company.control.two.converter;

import com.company.control.two.converter.Converter;

public class TempToN {
    public static double converterTemp(double degree) {
        return degree * 33 / 100;
    }
}

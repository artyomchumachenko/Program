package com.company.control.two.converter;

public interface Converter {
    static double converterTemp(double degree) {
        return degree;
    }
}
